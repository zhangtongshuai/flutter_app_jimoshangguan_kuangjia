import 'package:fluro/fluro.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/config/application.dart';
import 'package:flutter_app_jimoshangguan/config/routers.dart';
import 'package:flutter_app_jimoshangguan/utils/string_util.dart';
import 'package:flutter_app_jimoshangguan/utils/fluro_convert_utils.dart';

class NavigatorUtils {
  static goMallMainPage(BuildContext context) {
    Application.router.navigateTo(context, Routers.home,
        transition: TransitionType.inFromRight, replace: true);
  }

  static goLogin(BuildContext context) {
    Application.router.navigateTo(context, Routers.login,
        transition: TransitionType.inFromRight);
  }

}
