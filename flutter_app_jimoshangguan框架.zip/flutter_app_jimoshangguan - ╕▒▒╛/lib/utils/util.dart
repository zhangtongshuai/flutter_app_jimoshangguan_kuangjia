import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';

class Util {
  //弹框提示
  static showToast(String message) {
    Fluttertoast.showToast(
        msg: message,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIos: 1,
        backgroundColor: ThemeColors.colorHyaline,
        textColor: ThemeColors.colorWhite,
        fontSize: ScreenUtil().setSp(24));
  }

  static Future<bool> setStorage(String name, String value) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(name, value);
  }

  static Future<String> getStorage(String name) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(name);
  }

  static Future<bool> removeStorage(String name) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.remove(name);
  }


  static Future<bool> checkPermission(PermissionGroup permission) async {
    PermissionStatus permissionStatus = await PermissionHandler()
        .checkPermissionStatus(permission);
    if (permissionStatus != PermissionStatus.granted) {
      return await requestPermission(permission);
    } else {
      return true;
    }
  }

  static Future<bool> requestPermission(PermissionGroup permission) async {
    final List<PermissionGroup> permissions = <PermissionGroup>[permission];
    final Map<PermissionGroup,
        PermissionStatus> permissionRequestResult = await PermissionHandler()
        .requestPermissions(permissions);

    return permissionRequestResult[permission] == PermissionStatus.granted;
  }

  static String rand() {
//    var r = Random().nextInt(2147483646);
    var r = DateTime
        .now()
        .millisecondsSinceEpoch;
    return r.toString();
  }

  static String formatTime(DateTime time) {
    int today = DateTime
        .now()
        .day;
    if (time.day == today) {
      return "${time.hour.toString().padLeft(2, "0")}:${time.minute.toString()
          .padLeft(2, "0")}";
    } else if (today - time.day == 1) {
      return "昨天";
    } else if (today - time.day == 2) {
      return "前天";
    } else {
      return "${time.month.toString().padLeft(2, "0")}月${time.day.toString()
          .padLeft(2, "0")}日";
    }
  }

}