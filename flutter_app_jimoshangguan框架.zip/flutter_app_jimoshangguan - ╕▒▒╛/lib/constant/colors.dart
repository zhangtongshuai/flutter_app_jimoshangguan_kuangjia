import 'package:flutter/material.dart';
class ThemeColors {
  ///主色调，按钮，特殊需要强调和突出的文字
  static Color colorTheme = Color(0xff538AEF);

  ///主色调渐变用色，个别按钮和状态，从colorBtnTop变化到colorBtnBottom
  static Color colorBtnTop = Color(0xff538AEF);
  static Color colorBtnBottom = Color(0xff1CC5E9);
  static Color colorBtnFoot = Color(0xff20CFAC);
  //一些效果的背景色
  static Color colorBack = Color(0xff14233C);

  ///纯黑色
  static Color colorBlack = Color(0xff000000);

  //浅蓝色
  static Color colorWathet = Color(0xff80a6ec);
  static Color colorBlue = Color(0xff34D9FF);

  static Color colorNavyBlue = Color(0xff25447D);

  //价格红色
  static Color colorRed1 = Color(0xffFF0000);
  //提示红色
  static Color colorRed2 = Color(0xffE71F19);

  //按钮边框文字红色
  static Color colorRed3 = Color(0xffFF2D2D);

  //按钮边框文字红色
  static Color colorRed4 = Color(0xffFF1B1B);

  //黄色
  static Color colorYellow = Color(0xffFFA02E);

  //纯白色
  static Color colorWhite = Color(0xffFFFFFF);

  ///提示性文字，状态信息，按钮等
  static Color colorGrey = Color(0xffEDEDED);

  ///功能性较强的文字，内页标题等
  static Color color333333 = Color(0xff333333);

  ///背景区域划分，分割线
  static Color colorE6E6E6 = Color(0xffE6E6E6);

  ///正文，副标题以及可点击区域的主要文字和图标
  static Color color666666 = Color(0xff666666);

  ///弱化信息，提示性文字信息，不可点击状态
  static Color color999999 = Color(0xff999999);

  static Color colorF7F7F7 = Color(0xffF7F7F7);

  static Color colorF2F2F2 = Color(0xffF2F2F2);

  //浅色背景色
  static Color colorLight = Color(0xfffcf9fc);

  //透明灰色
  static Color colorHyaline =  Color.fromRGBO(0, 0, 0, 0.5);


}
