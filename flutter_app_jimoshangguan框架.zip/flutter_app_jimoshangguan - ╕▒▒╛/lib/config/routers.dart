import 'package:fluro/fluro.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/config/router_handlers.dart';

class Routers {
  static String root = "/";
  static String home = "/home";
  static String categoryGoodsList = "/categoryGoodsList";
  static String goodsDetail = "/goodsDetail";
  static String login = "/login";
  static String register = "/register";
  static String fillInOrder = "/fillInOrder";
  static String address = "/myAddress";
  static String addressEdit = "/addressEdit";
  static String feedback = "/feedback";
  static String mineCoupon = "/mineCoupon";
  static String mineFootprint = "/mineFootprint";
  static String mineCollect = "/mineCollect";
  static String aboutUs = "/aboutUs";
  static String mineOrder = "/mineOrder";
  static String mineOrderDetail = "/mineOrderDetail";
  static String searchGoods = "/searchGoods";
  static String projectSelectionDetail = "/projectSelectionDetail";
  static String webView = "/webView";
  static String brandDetail = "/brandDetail";

  static void configureRoutes(Router router) {
    router.notFoundHandler = Handler(handlerFunc:
        (BuildContext context, Map<String, List<String>> parameters) {
      print("handler not find");
    });

    router.define(root, handler: splashHandler);
    router.define(home, handler: homeHandler);
    router.define(login, handler: loginHandler);
    router.define(webView, handler: webViewHandler);
  }
}
