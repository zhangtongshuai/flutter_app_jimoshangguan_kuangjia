import 'package:fluro/fluro.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/page/home/mall.dart';
import 'package:flutter_app_jimoshangguan/page/splash/splash.dart';
import 'package:flutter_app_jimoshangguan/page/login/login_page.dart';
import 'package:flutter_app_jimoshangguan/utils/string_util.dart';
import 'package:flutter_app_jimoshangguan/widgets/webview.dart';
import 'package:flutter_app_jimoshangguan/utils/fluro_convert_utils.dart';
var homeHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
      return MallMainView();
    });
var splashHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
  return SplashView();
});

var loginHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
      return LoginPage();
    });

var webViewHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
  var title = FluroConvertUtil.fluroCnParamsDecode(parameters["title"].first);
  var url = FluroConvertUtil.fluroCnParamsDecode(parameters["url"].first);
  return WebViewPage(url, title);
});

