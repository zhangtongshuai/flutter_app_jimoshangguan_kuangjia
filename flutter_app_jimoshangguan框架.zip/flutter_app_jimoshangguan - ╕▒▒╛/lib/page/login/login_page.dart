import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/utils/navigator_util.dart';

class LoginPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

class Page extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeColors.colorWhite,
      body: new SingleChildScrollView(
        child: Container(
          height: 600.0,
          child: Column(
            children: <Widget>[
              new Column(
                children: <Widget>[
                  layout(context),
                  LoginPhoneInput(),
                  loginCodeInput(),
                  loginPassInput(),
                  loginButton(context)
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}

Widget layout(BuildContext context) {
  return Container(
    child: Column(
      children: <Widget>[
        new Padding(
          padding:new EdgeInsets.fromLTRB(0.0, 50.0, 0.0, 30.0),
          child: new Text(
            '即墨服装商务平台',
            style: TextStyle(
              color: ThemeColors.colorWhite,
              fontSize: 18.0,
            ),
          ),
        ),
        Container(
          width: 76.0,
          height: 76.0,
          decoration:new BoxDecoration(
            image: DecorationImage(image: NetworkImage(
                "http://img8.zol.com.cn/bbs/upload/23765/23764201.jpg"),
                fit: BoxFit.fill
            ),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: ThemeColors.color666666,
                offset: Offset(1.0, 0.0),
                blurRadius: 2.0,
                spreadRadius: 2.0,
              )
            ],
          ),
        ),
      ],
    ),
    height: 237.0,
    width:MediaQuery.of(context).size.width,
    decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage('images/bj.png'),
            fit: BoxFit.fill
        )
    ),
  );
}

TextEditingController phoneController = new TextEditingController();
TextEditingController codeController   = new TextEditingController();
TextEditingController passController   = new TextEditingController();

Widget LoginPhoneInput(){
  return new Padding(
    padding: EdgeInsets.fromLTRB(20.0, 10.0 ,20.0, 0.0),
    child: new Stack(
      alignment: Alignment(1.0, 1.0),
      children: <Widget>[
        new Row(
          children: <Widget>[
            new Expanded(
                child: new TextField(
                  controller: phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: new InputDecoration(
                    labelText: "请输入手机号",
                    prefixIcon: Icon(
                      IconData(
                        0xe61c,
                        fontFamily: 'myfont',
                      ),
                      color: ThemeColors.colorTheme,
                      size: 26.0,
                    ),
                    fillColor: ThemeColors.colorWhite,
                    filled: true,
                  ),
                )
            )
          ],
        ),
        new IconButton(
          icon: new Icon(
            IconData(
              0xe617,
              fontFamily: 'myfont',
            ),
            color: ThemeColors.colorTheme,
            size: 14.0,
          ),
          onPressed: (){
            phoneController.clear();
          } ,
        )
      ],
    ),
  );
}

Widget loginCodeInput(){
  return new Container(
    margin: EdgeInsets.fromLTRB(20.0, 10.0 ,20.0, 0.0),
    child: new Stack(
      alignment: Alignment(1.0, 1.0),
      children: <Widget>[
        new Row(
          children: <Widget>[
            new Expanded(
                child: new TextField(
                  controller: codeController,
                  keyboardType: TextInputType.number,
                  decoration: new InputDecoration(
//                      hintText: "请输入验证码",
                      labelText: '请输入验证码',
                      prefixIcon: Icon(
                        IconData(
                          0xe6bf,
                          fontFamily: 'myfont',
                        ),
                        color: ThemeColors.colorTheme,
                        size: 26.0,
                      ),
                      fillColor: ThemeColors.colorWhite,
                      filled: true,
                  ),
                )
            ),
          ],
        ),
        new FlatButton(
            color: ThemeColors.colorTheme,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(29.0),
            ),
            child: Text(
              '输入验证码',
              style: TextStyle(
                color: ThemeColors.colorWhite,
                fontSize: 12.0
              ),
            ),
            onPressed: (){
              codeController.clear();
            }
        )
      ],
    ) ,
  );
}

Widget loginPassInput(){
  return new Padding(
    padding: EdgeInsets.fromLTRB(20.0, 10.0 ,20.0, 0.0),
    child: new Stack(
      alignment: Alignment(1.0, 1.0),
      children: <Widget>[
        new Row(
          children: <Widget>[
            new Expanded(
                child: new TextField(
                  controller: passController,
                  obscureText: true,
                  keyboardType: TextInputType.text,
                  decoration: new InputDecoration(
                      labelText: "请输入密码",
                      prefixIcon: Icon(
                        IconData(
                          0xe87f,
                          fontFamily: 'myfont',
                        ),
                        color: ThemeColors.colorTheme,
                        size: 26.0,
                      ),
                      fillColor: ThemeColors.colorWhite,
                      filled: true,
                  ),
                )
            ),
          ],
        ),
      ],
    ),
  );
}

Widget loginButton(BuildContext context){
  return new Container(
    width: 300.0,
    height: 44.0,
    margin: EdgeInsets.only(top: 60.0),
    child: new RaisedButton(
      color: ThemeColors.colorTheme,
      splashColor: ThemeColors.colorTheme,
      elevation: 10.0,
      shape: StadiumBorder(),
      child: new Text(
        '登录',
        style: new TextStyle(
            color: ThemeColors.colorWhite,
            fontSize: 18.0,
        ),
      ),
      onPressed: (){
        _checkSub(context);
//        Navigator.of(context).pushAndRemoveUntil(
//            new MaterialPageRoute(builder: (context) => new MainPage()
//            ), (route) => route == null);
//        Navigator.push(context, MaterialPageRoute(
//            builder: (context){return MainPage();} //传入的是匿名函数
//          //builder:(context)=>SecondView()
//        ));
      },
    ),
  );
}

void _checkSub(BuildContext context){
  String msgStr = "";
  if(!phoneController.text.isNotEmpty ){
    msgStr = "请输入手机号";
  }else  if(!codeController.text.isNotEmpty){
    msgStr = "验证码不能为空";
  }else  if(!passController.text.isNotEmpty){
    msgStr = "密码不能为空";
  }

  if(msgStr != ''){
    showDialog(
        context: context,
        builder: (context){
          return new AlertDialog(
            title: new Text("提示信息"),
            content: new Text(msgStr),
            actions: <Widget>[
              new FlatButton(child: new Text("确定"),onPressed: (){
                Navigator.of(context).pop();
              }),
            ],
          );
        }
    );

  }else{
    NavigatorUtils.goMallMainPage(context);
  }
}

