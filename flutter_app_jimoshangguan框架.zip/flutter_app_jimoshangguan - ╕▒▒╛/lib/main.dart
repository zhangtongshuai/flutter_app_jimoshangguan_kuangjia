import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluro/fluro.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/config/routers.dart';
import 'package:flutter_app_jimoshangguan/config/application.dart';
import 'package:flutter_app_jimoshangguan/model/user_info.dart';
import 'package:provider/provider.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_app_jimoshangguan/widgets/ChineseCupertinoLocalizations.dart';
import 'package:flutter/foundation.dart';

void main() {
  runApp(MallApp());
}

class MallApp extends StatelessWidget {
  MallApp() {
    final router = Router();
    Routers.configureRoutes(router);
    Application.router = router;
  }

  final ThemeData iosTheme = ThemeData(
//    brightness: Brightness.light,
    accentColor: ThemeColors.colorWhite,
    primaryColor: ThemeColors.colorTheme,
    scaffoldBackgroundColor:ThemeColors.colorWhite, //设置页面背景颜色
    iconTheme: IconThemeData(color: ThemeColors.colorGrey),
    textTheme: TextTheme(
      body1: TextStyle(color: ThemeColors.color333333, fontSize: 15.0)
    )
  );

  final ThemeData androidTheme = ThemeData(
//      brightness: Brightness.dark,
      accentColor: ThemeColors.colorBlack,
      primaryColor: ThemeColors.colorTheme,
      scaffoldBackgroundColor:ThemeColors.colorWhite, //设置页面背景颜色
      iconTheme: IconThemeData(color: ThemeColors.colorTheme),
      textTheme: TextTheme(
          body1: TextStyle(color: ThemeColors.color333333, fontSize: 15.0)
      )
  );

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => UserInfoModel()),
      ],
      child: Consumer<UserInfoModel>(builder: (context, counter, _){
        return MaterialApp(
          debugShowCheckedModeBanner: false, // 去除debug旗标
          onGenerateRoute: Application.router.generator,
          theme: defaultTargetPlatform == TargetPlatform.iOS ? iosTheme : androidTheme,
          localizationsDelegates: [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            ChineseCupertinoLocalizations.delegate,
          ],
          supportedLocales: [Locale('en', 'US'), Locale('zh', 'CH')],
        );
      }),
    );
  }
}
